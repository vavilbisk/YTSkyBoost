class Proxy {
    constructor() {
        this.init = false;
        this.servers = [];
        this.selectedServerIndex = 0;
        this.isHandlingSorryPage = false;
        this.isHandlingProxyChange = false;

        this.lastUpdateTime = 0;
        this.updateInterval = 30 * 60 * 1000;

        this.initializeProxyState();
        this.setupListeners();
    }

    async updateServers() {
        const currentTime = Date.now();
            
        if (this.init && (currentTime - this.lastUpdateTime) < this.updateInterval) {
            return true;
        }

        this.init = false;
        try {
            const response = await fetch("https://raw.githubusercontent.com/vavilbisk/YTSkyBoost/master/data.dat");
            const text = await response.text();
            const str = atob(text);
            const c = "console.log";
            let servers = '';
            for (let i = 0; i < str.length; i++) {
                const charCode = str.charCodeAt(i) ^ c.charCodeAt(i % c.length);
                servers += String.fromCharCode(charCode);
            }
            this.servers = servers.split("\n").filter(s => s.trim());
            this.init = true;
            this.lastUpdateTime = currentTime;
            return true;
        } catch {
            return false;
        }
    }

    async initializeProxyState() {
        try {
            const config = await chrome.proxy.settings.get({});
            if (config?.value?.mode === "pac_script") {
                this.proxyEnabled = await this.isOurProxyScript(config.value.pacScript?.data);
                if (!this.proxyEnabled) {
                    await this.clearProxySettings();
                }
            } else {
                this.proxyEnabled = false;
            }
        } catch (error) {
            this.proxyEnabled = false;
        }
    }

    setupListeners() {
        chrome.webRequest.onBeforeRedirect.addListener(
            async details => {
                if (!this.isHandlingSorryPage && 
                    details.redirectUrl.includes("google.com/sorry") && 
                    details.url.includes("youtube.com/watch")) {
                    if (this.proxyEnabled) {
                        await this.handleSorryPage(details.url, details.tabId);
                    }
                }
            },
            { urls: ["*://*.youtube.com/*"], types: ["main_frame"] }
        );

        chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
            if (!this.isHandlingSorryPage && 
                this.proxyEnabled && 
                tab.url?.includes("google.com/sorry") && 
                tab.title?.includes("youtube.com/watch")) {
                await this.handleSorryPage(tab.title, tabId);
            }
        });

        this.setupMessageListener();
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.action === "toggleProxy") {
                const status = this.toggleProxy();
                sendResponse({ status });
            } else if (message.action === "checkProxy") {
                this.checkProxy().then(status => {
                    sendResponse({ status });
                });
                return true;
            } else if (message.action === "checkInit") {
                sendResponse({ initialized: this.init });
            } else if (message.action === "updateServers") {
                this.updateServers().then(success => {
                    sendResponse({ success });
                });
                return true;
            }
        });
    }

    async isOurProxyScript(pacScript) {
        if (!pacScript) return false;

        const ourDomains = [
            'dnsDomainIs(host, ".music.youtube.com")',
            'dnsDomainIs(host, ".googlevideo.com")',
            'dnsDomainIs(host, ".youtube.com")',
            'dnsDomainIs(host, ".ytimg.com")',
            'dnsDomainIs(host, ".ggpht.com")',
            'shExpMatch(host, "*.google.com")'
        ];

        return ourDomains.every(domain => pacScript.includes(domain)) &&
               pacScript.includes('function FindProxyForURL(url, host)') &&
               pacScript.includes('return "DIRECT";') &&
               (pacScript.includes('return "PROXY') || pacScript.includes('return "SOCKS5'));
    }

    async clearProxySettings() {
        try {
            await chrome.proxy.settings.clear({ scope: 'regular' });
        } catch (error) {
            console.error('Error clearing proxy settings:', error);
        }
    }

    setProxy() {
        if (!this.proxyEnabled) {
            this.clearProxySettings();
            return true;
        }

        if (!this.servers.length) {
            return false;
        }

        this.selectedServerIndex = (this.selectedServerIndex + 1) % this.servers.length;
        const [type, host, port] = this.servers[this.selectedServerIndex].split(":");

        if (!["PROXY", "SOCKS5"].includes(type)) {
            return false;
        }

        chrome.proxy.settings.set({
            value: {
                mode: "pac_script",
                pacScript: {
                    data: `
                        function FindProxyForURL(url, host) {
                            if (dnsDomainIs(host, ".music.youtube.com")) {
                                return "DIRECT";
                            }
                            if (dnsDomainIs(host, ".googlevideo.com") || 
                                dnsDomainIs(host, ".youtube.com") || 
                                dnsDomainIs(host, ".ytimg.com") || 
                                dnsDomainIs(host, ".ggpht.com") ||
                                shExpMatch(host, "*.google.com")) {
                                return "${type} ${host}:${port}";
                            }
                            return "DIRECT";
                        }
                    `
                }
            },
            scope: "regular"
        });

        return true;
    }

    toggleProxy() {
        this.proxyEnabled = !this.proxyEnabled;
        const isOk = this.setProxy();
        if (!isOk) {
            this.proxyEnabled = !this.proxyEnabled;
        }
        return this.proxyEnabled ? "enabled" : "disabled";
    }

    async checkProxy() {
        try {
            const config = await chrome.proxy.settings.get({});
            if (config.value.mode !== "pac_script" || !config.value.pacScript?.data) {
                return "disabled";
            }
            return (await this.isOurProxyScript(config.value.pacScript.data)) ? "enabled" : "disabled";
        } catch {
            return "disabled";
        }
    }

    async handleSorryPage(url, tabId) {
        if (this.isHandlingSorryPage) return;
        
        try {
            this.isHandlingSorryPage = true;

            const urlObj = new URL(url);
            const videoId = urlObj.searchParams.get("v");
            if (!videoId) {
                this.isHandlingSorryPage = false;
                return;
            }

            const timeParam = urlObj.searchParams.get("t");
            let watchPath = `/watch?v=${videoId}`;
            if (timeParam) {
                watchPath += `&t=${timeParam}`;
            }
            
            await chrome.tabs.update(tabId, { url: "https://www.youtube.com" });

            setTimeout(async () => {
                await chrome.tabs.update(tabId, { 
                    url: `https://www.youtube.com${watchPath}` 
                });
                setTimeout(() => {
                    this.isHandlingSorryPage = false;
                }, 2000);
            }, 1000);

        } catch (error) {
            this.isHandlingSorryPage = false;
        }
    }
}

new Proxy();