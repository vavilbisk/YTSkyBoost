let isConnected = true;
let isClicked = false;

const loadingElement = document.querySelector(".loading");
const loadedElement = document.querySelector(".loaded");
const header = document.querySelector(".header");
const buttonContainer = document.querySelector(".connect-container");
const button = buttonContainer.querySelector(".connect-btn");
const buttonTitle = buttonContainer.querySelector("span");
const waves = document.querySelectorAll(".wave");
// Обновляем серверы при каждом открытии popup
chrome.runtime.sendMessage({ action: "updateServers" });

function updateWavePulsing(isEnabled) {
    waves.forEach((wave, index) => {
        if (isEnabled) {
            wave.style.animation = `pulsing 2s ease-in-out infinite ${index * 0.3}s`;
        } else {
            wave.style.animation = '';
        }
    });
}

// Функция для проверки инициализации серверов
async function checkInitialization() {
    try {
        const response = await chrome.runtime.sendMessage({ action: "checkInit" });
        if (response && response.initialized) {
            loadingElement.classList.remove('visible');
            loadedElement.classList.add('visible');
            
            // Запускаем анимации после загрузки
            setTimeout(() => {
                header.classList.add("show");
            }, 50);

            setTimeout(() => {
                buttonContainer.classList.add("scale");
            }, 200);

            // Проверяем начальное состояние прокси
            chrome.runtime.sendMessage({ action: "checkProxy" }, (response) => {
                console.log(response);
                if (response && response.status === "enabled") {
                    buttonContainer.classList.add("connected");
                    buttonTitle.textContent = "Подключено";
                    isConnected = true;
                    updateWavePulsing(true);
                } else {
                    buttonContainer.classList.remove("connected");
                    buttonTitle.textContent = "Отключено";
                    isConnected = false;
                    updateWavePulsing(false);
                }
            });
        } else {
            // Если серверы еще не инициализированы, проверяем снова через 500мс
            setTimeout(checkInitialization, 500);
        }
    } catch (error) {
        console.error("Error checking initialization:", error);
        setTimeout(checkInitialization, 500);
    }
}

// Запускаем проверку инициализации
checkInitialization();


button.addEventListener("click", async function () {
    isClicked = true;

    try {
        const response = await chrome.runtime.sendMessage({ action: "toggleProxy" });
        const newState = response.status === "enabled";
        
        buttonContainer.classList.toggle("connected", newState);
        buttonTitle.textContent = newState ? "Подключено" : "Отключено";
        updateWavePulsing(newState);
        
        isConnected = newState;
    } catch (error) {
        console.error("Error toggling proxy:", error);
    }
    
    button.classList.add("no-hover");

    // Анимация волн с последовательным запуском
    waves.forEach((wave, index) => {
        wave.classList.remove("animate");
        void wave.offsetWidth; // Сброс анимации
        setTimeout(() => {
            wave.classList.add("animate");
        }, index * 100); // Каждая следующая волна начинается с задержкой
    });
});

// Сброс состояния hover после отпускания кнопки
button.addEventListener("mouseleave", function () {
    if (isClicked) {
        button.classList.remove("no-hover");
        isClicked = false;
    }
});

// Очистка классов анимации после её завершения
waves.forEach(wave => {
    wave.addEventListener("animationend", function() {
        wave.classList.remove("animate");
    });
});