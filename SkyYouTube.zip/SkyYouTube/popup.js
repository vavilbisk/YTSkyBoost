const button = document.querySelector(".connect-btn");
const buttonTitle = document.querySelector(".connect-container > span");

// Проверка состояния прокси
chrome.runtime.sendMessage({ action: "checkProxy" }, (response) => {
    if (response.status === "enabled") {
        buttonTitle.textContent = "Подключено";
        button.classList.add("connected");
    } else {
        buttonTitle.textContent = "Отключено";
        button.classList.remove("connected");
    }
});

// Обработчик нажатия кнопки
button.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "toggleProxy" }).then((response) => {
        if (response.status === "enabled") {
            buttonTitle.textContent = "Подключено";
            button.classList.add("connected");
        } else {
            buttonTitle.textContent = "Отключено";
            button.classList.remove("connected");
        }
    });
});
